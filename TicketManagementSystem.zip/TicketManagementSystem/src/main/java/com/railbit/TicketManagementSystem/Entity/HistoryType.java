package com.railbit.TicketManagementSystem.Entity;

public enum HistoryType {
    CREATED,
    STATUS_CHANGED,
    ASSIGNED,
    COMMENT_ADDED,
    SLA_BREACHED,
    PRIORITY_CHANGED,
    DEPARTMENT_CHANGED,
    FILE_UPLOADED,
    CLOSED,
    RESOLVED,
    IN_PROGRESS
}
